
import React, { useState, useCallback, useEffect, useMemo } from 'react';
import { BlueprintView } from './components/BlueprintView';
import { blueprintData as initialBlueprintData, dummyProjects, dummyTasks, dummyClients, dummyExpenses, dummyRevenueItems, dummyInvoices, dummyDeals } from './constants'; // Added dummyDeals
import { MonitoringSection } from './components/MonitoringSection';
import { Sidebar } from './components/Sidebar';
import { 
  BlueprintData, Activity, ViewName, ViewConfig, Project, Task, NewProjectData, NewTaskData, Client, ProjectFilterStatus, 
  CrmBlueprintActivity, Expense, NewExpenseData, RevenueItem, NewRevenueData, Invoice, NewInvoiceData, InvoiceStatus, 
  InvoiceLineItem, RevenueSource, Deal, FinanceSubViewTarget, ParsedProjectPlan, ParsedTask 
} from './types';
import { StructuredViewLayout } from './components/StructuredViewLayout';
import { ImportProjectModal } from './components/views/projects/ImportProjectModal'; // Added

// Define view configurations
const viewConfigurations: Record<ViewName, ViewConfig> = {
  blueprint: {
    label: "Strategic Blueprint",
    icon: '🗺️', 
  },
  clients: {
    label: "Clients Management",
    icon: '🧑‍💼',
    defaultSubViewId: 'list',
    subViews: [
      { id: 'list', label: 'Client List', icon: '👥' },
      { id: 'profiles', label: 'Client Profiles', icon: '👤'},
      { id: 'communication', label: 'Communication Log', icon: '💬' }
    ]
  },
  projects: {
    label: "Project Hub",
    icon: '🏗️',
    defaultSubViewId: 'dashboard',
    subViews: [
      { id: 'dashboard', label: 'Dashboard', icon: '📊' },
      { id: 'all', label: 'All Projects', icon: '📚' },
      { id: 'detail', label: 'Project Details', icon: '📄' }, 
      // { id: 'board', label: 'Task Board', icon: '📋' } // Removed Task Board
    ]
  },
  tasks: {
    label: "Task Management",
    icon: '✅',
    defaultSubViewId: 'my_tasks',
    subViews: [
      { id: 'my_tasks', label: 'My Tasks', icon: '🙋‍♂️'},
      { id: 'team_tasks', label: 'Team Tasks', icon: '👨‍👩‍👧‍👦' },
      { id: 'calendar', label: 'Calendar View', icon: '📅' },
      { id: 'board', label: 'Task Board', icon: '📋' } // Task Board can exist here
    ]
  },
  crm: {
    label: "CRM Dashboard",
    icon: '🤝',
    defaultSubViewId: 'overview',
    subViews: [
      { id: 'overview', label: 'Overview', icon: '🌍' },
      { id: 'leads', label: 'Leads', icon: '🎣' },
      { id: 'prospects', label: 'Prospects', icon: '🎯' }, // Added Prospects
      { id: 'deals', label: 'Deals', icon: '💰'},
      { id: 'contacts', label: 'Contacts', icon: '📒'}
    ]
  },
  finance: {
    label: "Financial Overview",
    icon: '💰',
    defaultSubViewId: 'summary',
    subViews: [
      { id: 'summary', label: 'Summary', icon: '🧾' },
      { id: 'invoices', label: 'Invoices', icon: '✉️' },
      { id: 'revenue', label: 'Revenue', icon: '📈' },
      { id: 'expenses', label: 'Expenses', icon: '💸' }
    ]
  }
};


const App: React.FC = () => {
  const [currentBlueprintData, setCurrentBlueprintData] = useState<BlueprintData>(initialBlueprintData);
  const [projects, setProjects] = useState<Project[]>(dummyProjects);
  const [tasks, setTasks] = useState<Task[]>(dummyTasks);
  const [clients, setClients] = useState<Client[]>(dummyClients); 
  const [expenses, setExpenses] = useState<Expense[]>(dummyExpenses);
  const [revenueItems, setRevenueItems] = useState<RevenueItem[]>(dummyRevenueItems);
  const [invoices, setInvoices] = useState<Invoice[]>(dummyInvoices);
  const [deals, setDeals] = useState<Deal[]>(dummyDeals); 

  const [activeView, setActiveView] = useState<ViewName>('blueprint');
  const [activeSubViewId, setActiveSubViewId] = useState<string | null>(() => {
    const initialConfig = viewConfigurations['blueprint'];
    return initialConfig?.defaultSubViewId || null;
  });
  const [selectedClientIdForProfile, setSelectedClientIdForProfile] = useState<string | null>(null);
  
  const [projectListFilter, setProjectListFilter] = useState<ProjectFilterStatus>('All');
  const [selectedProjectIdForDetail, setSelectedProjectIdForDetail] = useState<string | null>(null);
  const [invoiceListFilter, setInvoiceListFilter] = useState<InvoiceStatus | 'All'>('All');
  const [isImportModalOpen, setIsImportModalOpen] = useState(false); // For AI Project Import Modal


  const crmBlueprintActivities = useMemo((): CrmBlueprintActivity[] => {
    const activities: CrmBlueprintActivity[] = [];
    currentBlueprintData.phases.forEach(phase => {
      phase.keyActivities.forEach(activity => {
        if (activity.crmDetails?.isCrmActivity && activity.crmDetails) {
          activities.push({
            id: activity.id,
            title: activity.title,
            crmDetails: activity.crmDetails,
          });
        }
      });
    });
    return activities;
  }, [currentBlueprintData]);

  const allBlueprintActivities = useMemo((): Activity[] => {
    return currentBlueprintData.phases.flatMap(phase => phase.keyActivities);
  }, [currentBlueprintData]);


  useEffect(() => {
    const currentViewConfig = viewConfigurations[activeView];
    if (!currentViewConfig) return;

    // Case 1: Project selected, and user intends to see its details.
    // This state should be preserved.
    if (activeView === 'projects' && selectedProjectIdForDetail && activeSubViewId === 'detail') {
      return; // Do nothing, let the intended project-specific view render.
    }

    // Case 2: On a project-specific view (detail) but no project is selected.
    // This is an invalid state; revert to the project dashboard.
    if (activeView === 'projects' && 
        activeSubViewId === 'detail' && 
        selectedProjectIdForDetail === null) {
      setActiveSubViewId(currentViewConfig.defaultSubViewId || 'dashboard');
      return;
    }

    // Case 3: General subview validity check and default setting for the activeView.
    // This applies if Cases 1 and 2 are not met (e.g., changing main views, or on non-project-specific subviews).
    const isValidSubView = currentViewConfig.subViews?.find(sv => sv.id === activeSubViewId);
    if (currentViewConfig.defaultSubViewId && (activeSubViewId === null || !isValidSubView)) {
      setActiveSubViewId(currentViewConfig.defaultSubViewId);
    }
  }, [activeView, activeSubViewId, selectedProjectIdForDetail]);


  const handleUpdateActivity = useCallback((phaseId: string, activityId: string, updatedActivityData: Partial<Activity>) => {
    setCurrentBlueprintData(prevData => {
      const newPhases = prevData.phases.map(phase => {
        if (phase.id === phaseId) {
          return {
            ...phase,
            keyActivities: phase.keyActivities.map(activity => {
              if (activity.id === activityId) {
                return { ...activity, ...updatedActivityData };
              }
              return activity;
            }),
          };
        }
        return phase;
      });
      return { ...prevData, phases: newPhases };
    });
  }, []);

  const handleSetActiveView = useCallback((view: ViewName) => {
    setActiveView(view);
    setSelectedClientIdForProfile(null); 
    setSelectedProjectIdForDetail(null); 
    const config = viewConfigurations[view];
    setActiveSubViewId(config?.defaultSubViewId || null);
    if (view !== 'projects') { 
      setProjectListFilter('All');
    }
    if (view !== 'finance' || (view === 'finance' && config?.defaultSubViewId !== 'invoices')) {
      setInvoiceListFilter('All');
    }
  }, []);

  const handleSetSubViewId = useCallback((subViewId: string | null) => {
    setActiveSubViewId(subViewId);
    if (activeView === 'projects' && subViewId !== 'detail') { // No 'board' check needed here anymore for projects
        setSelectedProjectIdForDetail(null); 
    }
     if (activeView === 'projects' && subViewId === 'all') { 
        setSelectedProjectIdForDetail(null);
    }
    if (activeView === 'finance' && subViewId !== 'invoices') {
        setInvoiceListFilter('All'); 
    }
  }, [activeView]);

  const handleViewClientProfileFromList = useCallback((clientId: string) => {
    setSelectedClientIdForProfile(clientId);
    setActiveSubViewId('profiles'); 
  }, []);

  const handleClientSelectionInProfileView = useCallback((clientId: string | null) => {
    setSelectedClientIdForProfile(clientId);
    if (activeSubViewId !== 'profiles') { 
        setActiveSubViewId('profiles');
    }
  }, [activeSubViewId]);
  
  const handleBackToClientList = useCallback(() => {
    setSelectedClientIdForProfile(null);
    setActiveSubViewId('list'); 
  }, []);

  const handleNavigateToCommLogForClient = useCallback((clientId: string) => {
    setSelectedClientIdForProfile(clientId); // Set client context
    if (activeView !== 'clients') setActiveView('clients'); // Switch to clients view if not already there
    setActiveSubViewId('communication'); // Switch to communication log
  }, [activeView]);

  const handleSaveProject = useCallback((projectData: NewProjectData, idToUpdate?: string): string => {
    const client = clients.find(c => c.id === projectData.clientId);
    let projectId = idToUpdate;
    if (idToUpdate) {
      setProjects(prev => prev.map(p => p.id === idToUpdate ? { ...p, ...projectData, clientName: client?.clientName } : p));
    } else {
      const newProject: Project = {
        ...projectData,
        id: `proj_${Date.now()}`,
        clientName: client?.clientName,
      };
      projectId = newProject.id;
      setProjects(prev => [newProject, ...prev]);
    }
    return projectId!; // idToUpdate or newProject.id will be defined
  }, [clients]);

  const handleDeleteProject = useCallback((projectId: string) => {
    setProjects(prev => prev.filter(p => p.id !== projectId));
    setTasks(prevTasks => prevTasks.filter(t => t.projectId !== projectId));
    setInvoices(prevInvoices => prevInvoices.map(inv => inv.projectId === projectId ? {...inv, projectId: undefined, projectName: undefined} : inv));
    setExpenses(prevExpenses => prevExpenses.map(exp => exp.projectId === projectId ? {...exp, projectId: undefined, projectName: undefined} : exp));
    setRevenueItems(prevRevenue => prevRevenue.map(rev => rev.projectId === projectId ? {...rev, projectId: undefined, projectName: undefined} : rev));

    if (selectedProjectIdForDetail === projectId) { 
      setSelectedProjectIdForDetail(null);
      // The useEffect will handle setting activeSubViewId to default if necessary
    }
  }, [selectedProjectIdForDetail]);

  const handleSaveTask = useCallback((taskData: NewTaskData, idToUpdate?: string) => {
    const project = projects.find(p => p.id === taskData.projectId);
    let taskToSave: Task;
    let crmInfoSnippet;
    if (taskData.linkedBlueprintActivityId) {
        const linkedBlueprintActivity = crmBlueprintActivities.find(act => act.id === taskData.linkedBlueprintActivityId);
        if (linkedBlueprintActivity && linkedBlueprintActivity.crmDetails) {
            crmInfoSnippet = {
                blueprintActivityTitle: linkedBlueprintActivity.title,
                customerName: linkedBlueprintActivity.crmDetails.customerName,
                dealStage: linkedBlueprintActivity.crmDetails.dealStage,
                estimatedValue: linkedBlueprintActivity.crmDetails.estimatedValue,
            };
        }
    }
    if (idToUpdate) {
      setTasks(prev => prev.map(t => {
        if (t.id === idToUpdate) {
          return { ...t, ...taskData, projectName: project?.projectName, crmInfoSnippet: taskData.linkedBlueprintActivityId ? crmInfoSnippet : undefined };
        }
        return t;
      }));
    } else {
      taskToSave = { ...taskData, id: `task_${Date.now()}`, projectName: project?.projectName, crmInfoSnippet: crmInfoSnippet };
      setTasks(prev => [taskToSave, ...prev]);
    }
  }, [projects, crmBlueprintActivities]);

  const handleDeleteTask = useCallback((taskId: string) => {
    setTasks(prev => prev.filter(t => t.id !== taskId));
  }, []);

  const handleUpdateTaskStatus = useCallback((taskId: string, status: Task['status']) => {
    setTasks(prev => prev.map(t => t.id === taskId ? { ...t, status } : t));
  }, []);

  const handleApplyProjectFilterAndNavigate = useCallback((filter: ProjectFilterStatus) => {
    setProjectListFilter(filter);
    setActiveView('projects');
    setActiveSubViewId('all');
    setSelectedProjectIdForDetail(null); 
  }, []);

  const handleClearProjectFilter = useCallback(() => {
    setProjectListFilter('All');
  }, []);

  const handleSelectProjectForNavigation = useCallback((projectId: string) => {
    setSelectedProjectIdForDetail(projectId);
    setActiveView('projects'); 
    setActiveSubViewId('detail'); // Navigate to project detail view
  }, []);

  const handleBackToProjectList = useCallback(() => { 
    setSelectedProjectIdForDetail(null);
    setActiveSubViewId('all'); 
  }, []);

  const handleSaveExpense = useCallback((expenseData: NewExpenseData, idToUpdate?: string) => {
    const project = projects.find(p => p.id === expenseData.projectId);
    if (idToUpdate) {
      setExpenses(prev => prev.map(exp => exp.id === idToUpdate ? { ...exp, ...expenseData, projectName: project?.projectName } : exp));
    } else {
      const newExpense: Expense = { ...expenseData, id: `exp_${Date.now()}`, projectName: project?.projectName };
      setExpenses(prev => [newExpense, ...prev].sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime()));
    }
  }, [projects]);

  const handleDeleteExpense = useCallback((expenseId: string) => {
    setExpenses(prev => prev.filter(exp => exp.id !== expenseId));
  }, []);

  const handleSaveRevenueItem = useCallback((revenueData: NewRevenueData, idToUpdate?: string) => {
    const project = projects.find(p => p.id === revenueData.projectId);
    const client = clients.find(c => c.id === revenueData.clientId);
    if (idToUpdate) {
      setRevenueItems(prev => prev.map(rev => rev.id === idToUpdate ? { ...rev, ...revenueData, projectName: project?.projectName, clientName: client?.clientName } : rev));
    } else {
      const newRevenueItem: RevenueItem = { ...revenueData, id: `rev_${Date.now()}`, projectName: project?.projectName, clientName: client?.clientName };
      setRevenueItems(prev => [newRevenueItem, ...prev].sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime()));
    }
  }, [projects, clients]);

  const handleDeleteRevenueItem = useCallback((revenueId: string) => {
    setRevenueItems(prev => prev.filter(rev => rev.id !== revenueId));
  }, []);

  const generateInvoiceNumber = useCallback((): string => {
    const latestInvoiceNumber = invoices.map(inv => parseInt(inv.invoiceNumber.split('-')[2])).filter(num => !isNaN(num)).sort((a, b) => b - a)[0] || 0;
    return `INV-${new Date().getFullYear()}-${(latestInvoiceNumber + 1).toString().padStart(3, '0')}`;
  }, [invoices]);

  const calculateInvoiceTotals = (lineItems: Array<Omit<InvoiceLineItem, 'id' | 'total'>>, taxRate?: number) => {
    const itemsWithTotals = lineItems.map((item, index) => ({ ...item, id: `li_${Date.now()}_${index}`, total: item.quantity * item.unitPrice }));
    const subtotal = itemsWithTotals.reduce((sum, item) => sum + item.total, 0);
    const currentTaxRate = taxRate === undefined || isNaN(taxRate) ? 0 : taxRate;
    const taxAmount = subtotal * currentTaxRate;
    const totalAmount = subtotal + taxAmount;
    return { itemsWithTotals, subtotal, taxAmount, totalAmount };
  };

  const handleSaveInvoice = useCallback((invoiceData: NewInvoiceData, idToUpdate?: string) => {
    const client = clients.find(c => c.id === invoiceData.clientId);
    const project = projects.find(p => p.id === invoiceData.projectId);
    const { itemsWithTotals, subtotal, taxAmount, totalAmount } = calculateInvoiceTotals(invoiceData.lineItems, invoiceData.taxRate);
    if (idToUpdate) {
      setInvoices(prev => prev.map(inv => inv.id === idToUpdate ? { ...inv, ...invoiceData, clientName: client?.clientName || 'N/A', projectName: project?.projectName, lineItems: itemsWithTotals, subtotal, taxAmount, totalAmount } : inv));
    } else {
      const newInvoice: Invoice = { ...invoiceData, id: `inv_${Date.now()}`, invoiceNumber: generateInvoiceNumber(), clientName: client?.clientName || 'N/A', projectName: project?.projectName, lineItems: itemsWithTotals, subtotal, taxAmount, totalAmount };
      setInvoices(prev => [newInvoice, ...prev].sort((a,b) => new Date(b.issueDate).getTime() - new Date(a.issueDate).getTime()));
    }
  }, [clients, projects, generateInvoiceNumber]);

  const handleDeleteInvoice = useCallback((invoiceId: string) => {
    setInvoices(prev => prev.filter(inv => inv.id !== invoiceId));
    setRevenueItems(prev => prev.map(rev => rev.invoiceId === invoiceId ? {...rev, invoiceId: undefined, description: rev.description.replace(/Payment for Invoice.*$/, "Previously linked invoice deleted")} : rev));
  }, []);
  
  const handleUpdateInvoiceStatus = useCallback((invoiceId: string, status: InvoiceStatus, paymentDateOverride?: string) => {
    setInvoices(prevInvoices => prevInvoices.map(inv => {
      if (inv.id === invoiceId) {
        const updatedInvoice = { ...inv, status, paymentDate: status === 'Paid' ? (paymentDateOverride || inv.paymentDate || new Date().toISOString()) : inv.paymentDate };
        if (status === 'Paid') {
          const existingRevenue = revenueItems.find(r => r.invoiceId === invoiceId);
          if (!existingRevenue) {
            const revenueData: NewRevenueData = { date: updatedInvoice.paymentDate!, source: 'Invoice Payment' as RevenueSource, description: `Payment for Invoice ${updatedInvoice.invoiceNumber}`, amount: updatedInvoice.totalAmount, projectId: updatedInvoice.projectId, clientId: updatedInvoice.clientId, invoiceId: updatedInvoice.id };
            const newRevenueItem: RevenueItem = { ...revenueData, id: `rev_auto_${Date.now()}`, projectName: updatedInvoice.projectName, clientName: updatedInvoice.clientName };
            setRevenueItems(prevRev => [...prevRev, newRevenueItem].sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime()));
          }
        }
        return updatedInvoice;
      }
      return inv;
    }));
  }, [revenueItems]); 

  const handleGenerateRevenueFromInvoice = useCallback((invoice: Invoice) => {
    const existingRevenue = revenueItems.find(r => r.invoiceId === invoice.id);
    if (existingRevenue) { alert(`Revenue for invoice ${invoice.invoiceNumber} already exists.`); return; }
    const revenueData: NewRevenueData = { date: invoice.paymentDate || new Date().toISOString(), source: 'Invoice Payment' as RevenueSource, description: `Payment for Invoice ${invoice.invoiceNumber}`, amount: invoice.totalAmount, projectId: invoice.projectId, clientId: invoice.clientId, invoiceId: invoice.id };
    handleSaveRevenueItem(revenueData); 
  }, [revenueItems, handleSaveRevenueItem]);

  const handleNavigateToFinanceFilteredView = useCallback((targetView: FinanceSubViewTarget, filter?: InvoiceStatus | string) => {
    setActiveView('finance');
    setActiveSubViewId(targetView);
    if (targetView === 'invoices' && filter) {
      setInvoiceListFilter(filter as InvoiceStatus | 'All');
    } else {
      setInvoiceListFilter('All'); 
    }
  }, []);

  const handleClearInvoiceFilter = useCallback(() => {
    setInvoiceListFilter('All');
  }, []);

  // AI Project Import Handlers
  const handleOpenImportModal = useCallback(() => setIsImportModalOpen(true), []);
  const handleCloseImportModal = useCallback(() => setIsImportModalOpen(false), []);

  const handleImportProjectPlan = useCallback(async (parsedPlan: ParsedProjectPlan): Promise<string | null> => {
    try {
      const projectDescription = (parsedPlan.projectManager ? `Project Manager: ${parsedPlan.projectManager}\n\n` : '') + (parsedPlan.projectDescription || '');
      
      const newProjectCoreData: NewProjectData = {
        projectName: parsedPlan.projectName || 'Untitled Imported Project',
        description: projectDescription,
        clientId: undefined, // AI import doesn't specify client yet
        status: 'Planning',
        startDate: parsedPlan.startDate || undefined,
        dueDate: parsedPlan.endDate || undefined,
        teamMembers: [], // AI doesn't parse team members at project level yet
      };

      const newProjectId = handleSaveProject(newProjectCoreData);

      if (newProjectId && parsedPlan.phases) {
        for (const phase of parsedPlan.phases) {
          if (phase.tasks) {
            for (const parsedTask of phase.tasks) {
              const newTaskData: NewTaskData = {
                title: parsedTask.title || 'Untitled Task',
                description: parsedTask.description || '',
                projectId: newProjectId,
                status: 'To Do',
                priority: 'Medium',
                assignedTo: parsedTask.assignedTo || undefined,
                startDate: parsedTask.startDate || undefined,
                dueDate: parsedTask.dueDate || undefined,
              };
              handleSaveTask(newTaskData); // This function will generate the task ID
            }
          }
        }
      }
      setActiveView('projects'); // Navigate to projects view
      handleSelectProjectForNavigation(newProjectId); // Navigate to the new project's detail view
      return newProjectId;
    } catch (error) {
      console.error("Error importing project plan:", error);
      // Potentially set an error state to show in UI
      return null;
    }
  }, [handleSaveProject, handleSaveTask, handleSelectProjectForNavigation]);


  const renderActiveView = () => {
    const currentViewConfig = viewConfigurations[activeView];
    switch (activeView) {
      case 'blueprint':
        return (<><BlueprintView phases={currentBlueprintData.phases} onUpdateActivity={handleUpdateActivity} /><MonitoringSection title="Monitoring Your Progress & Fighting Squirrels" tips={currentBlueprintData.monitoringTips} /></>);
      case 'clients': case 'projects': case 'tasks': case 'crm': case 'finance':
        if (!currentViewConfig) return <p className="text-center py-10 text-slate-400">Configuration missing for {activeView}.</p>;
        return (
          <StructuredViewLayout
            viewName={activeView}
            config={currentViewConfig}
            activeSubViewId={activeSubViewId}
            onSetSubViewId={handleSetSubViewId}
            
            selectedClientIdForProfile={activeView === 'clients' ? selectedClientIdForProfile : null}
            onViewClientProfileFromList={activeView === 'clients' ? handleViewClientProfileFromList : undefined}
            onClientSelectedInProfileView={activeView === 'clients' ? handleClientSelectionInProfileView : undefined}
            onBackToClientList={activeView === 'clients' ? handleBackToClientList : undefined}
            onNavigateToCommLogForClient={handleNavigateToCommLogForClient} // Pass this for all views that might use it

            projects={projects} 
            onSaveProject={handleSaveProject}
            onDeleteProject={handleDeleteProject}
            projectListFilter={activeView === 'projects' ? projectListFilter : 'All'}
            onApplyProjectFilter={activeView === 'projects' ? handleApplyProjectFilterAndNavigate : undefined}
            onClearProjectFilter={activeView === 'projects' && activeSubViewId === 'all' ? handleClearProjectFilter : undefined}
            onViewProjectDetails={activeView === 'projects' ? handleSelectProjectForNavigation : undefined} 
            selectedProjectIdForDetail={activeView === 'projects' ? selectedProjectIdForDetail : null}
            onBackToProjectList={activeView === 'projects' && activeSubViewId === 'detail' ? handleBackToProjectList : undefined}
            onOpenImportModal={activeView === 'projects' && activeSubViewId === 'all' ? handleOpenImportModal : undefined} // Pass handler
            
            tasks={tasks} 
            onSaveTask={handleSaveTask}
            onDeleteTask={handleDeleteTask}
            onUpdateTaskStatus={handleUpdateTaskStatus}

            expenses={expenses}
            onSaveExpense={handleSaveExpense}
            onDeleteExpense={handleDeleteExpense}
            revenueItems={revenueItems}
            onSaveRevenue={handleSaveRevenueItem}
            onDeleteRevenue={handleDeleteRevenueItem}
            invoices={invoices}
            onSaveInvoice={handleSaveInvoice}
            onDeleteInvoice={handleDeleteInvoice}
            onUpdateInvoiceStatus={handleUpdateInvoiceStatus}
            onGenerateRevenueFromInvoice={handleGenerateRevenueFromInvoice}
            invoiceListFilter={activeView === 'finance' && activeSubViewId === 'invoices' ? invoiceListFilter : 'All'}
            onClearInvoiceFilter={activeView === 'finance' && activeSubViewId === 'invoices' ? handleClearInvoiceFilter : undefined}
            onNavigateToFinanceFilteredView={activeView === 'finance' && activeSubViewId === 'summary' ? handleNavigateToFinanceFilteredView : undefined}
            
            clients={clients} 
            deals={deals} 
            crmBlueprintActivities={crmBlueprintActivities}
            blueprintActivities={allBlueprintActivities} // Pass all blueprint activities
          />
        );
      default:
        const exhaustiveCheck: never = activeView; 
        return <p className="text-center py-10 text-slate-400">An unexpected view was selected: {exhaustiveCheck}.</p>;
    }
  };

  return (
    <div className="flex h-screen overflow-hidden bg-[#1B365D] text-white antialiased"> {/* Updated: Fae Intelligence Blue bg, white text */}
      <Sidebar activeView={activeView} setActiveView={handleSetActiveView} />
      <div className="flex-1 flex flex-col overflow-hidden">
        <header className="p-4 md:p-6 text-center border-b border-opacity-30 border-[#4A5568] shadow-lg bg-[#1B365D]"> {/* Updated: border to Professional Gray (subtle) */}
          <h1 className="text-3xl md:text-4xl font-bold text-white">Consultancy Dashboard</h1> {/* Updated: text to white */}
        </header>
        <main className="flex-1 p-4 md:p-8 overflow-y-auto space-y-12 bg-[#F7FAFC] text-[#4A5568]"> {/* Updated: Light Gray bg, Professional Gray text for content area */}
          {renderActiveView()}
        </main>
        <footer className="py-6 text-center text-slate-400 border-t border-opacity-30 border-[#4A5568] bg-[#1B365D]"> {/* Updated: border, text */}
          <p>&copy; {new Date().getFullYear()} Your Consultancy Dashboard. Stay Productive.</p>
        </footer>
      </div>
      {isImportModalOpen && (
        <ImportProjectModal
          isOpen={isImportModalOpen}
          onClose={handleCloseImportModal}
          onImport={handleImportProjectPlan}
        />
      )}
    </div>
  );
};

export default App;